import components.map.Map;
import components.map.Map.Pair;
import components.map.Map2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.stack.Stack;
import components.stack.Stack2;

/**
 * Using an input file from a user, generates a series of output files of which
 * a glossary index can be accessed.
 *
 * @author Ray Kueterman
 *
 */
public final class GlossaryGenerator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private GlossaryGenerator() {
    }

    /**
     * Inputs a map of words and their definitions from the given file and
     * stores them in the given {@code Map}.
     *
     * @param fileName
     *            the name of the input file
     * @param wordMap
     *            the word -> wordMap
     * @replaces wordMap
     * @requires <pre>
     * [file named fileName exists but is not open, and has the
     *  format of one "word" (unique in the file) and one definition
     *  per line, with word and definition separated by an empty line,
     *  and ending with an empty line
     * </pre>
     * @ensures [wordMap contains word -> definition from file fileName]
     */
    public static void getWordMap(String fileName,
            Map<String, String> wordMap) {

        //create simplereader to access words and a copy map to store
        //data in loop
        SimpleReader input = new SimpleReader1L(fileName);
        Map<String, String> mapCopy = wordMap.newInstance();
        //loop that continues while there is still data unaccessed
        while (!input.atEOS()) {
            //gather assumed information first, with a secondary loop for
            //multiple-line definitions (using SB for best practice)
            String word = input.nextLine();
            String definition = "";
            String line = input.nextLine();
            StringBuilder definitionSB = new StringBuilder();
            while (!line.isEmpty()) {
                definitionSB.append(line);
                line = input.nextLine();
            }
            definition = definitionSB.toString();
            mapCopy.add(word, definition);
        }
        //transfer from copy to replace wordMap
        wordMap.transferFrom(mapCopy);

        //close input simplereader
        input.close();
    }

    /**
     * Takes an element from a given map and constructs an html element to be ma
     *
     * @param wordMap
     *            the word -> wordDefinition
     * @param word
     *            the word being used to create page
     * @param outFile
     *            the name of the outFile where the html is to be
     *
     *
     * @returns html link to 'word'
     * @requires <pre>
     * [outFile exists and word exists as a key in wordMap]
     * </pre>
     * @ensures [wordMap contains word -> definition from file fileName]
     */
    public static String processItem(Map<String, String> wordMap, String word,
            String outFile) {

        //create new location variable and create html and writer for it
        String location = outFile + "/" + word + ".html";
        SimpleWriter itemOut = new SimpleWriter1L(location);

        //call createItemPage method
        createItemPage(wordMap, word, itemOut);

        location = "<a href=" + word + ".html>" + word + "</a>";

        //return html link format to location within file
        return location;
    }

    /*
     * Takes a word and its original wordMap, and constructs the body of an html
     * file for it, using the definition provided in wordMap
     *
     * @param wordMap word -> definition
     *
     * @param word word to create termPage from
     *
     * @param out SimpleWriter to write to file of termPage
     *
     * @ensures valid output to html file
     *
     * @requires definition is properly formatted
     */
    public static void createItemPage(Map<String, String> wordMap, String word,
            SimpleWriter out) {

        //print header to file
        out.println(
                "<html> <head> <title> " + word + " </title> </head> <body>");
        out.println("<h1> <p style=\"color:red;\"> <b> <i> " + word
                + " </b> </i> </p> </h1>");
        out.println("<hr class=\"hr3\">");

        //print out definition in paragraph
        out.println("<p> " + wordMap.value(word) + " </p>");

        //print out return to index and close
        out.println("<hr class=\"hr3\">");
        out.println("<p> Return to <a href=index.html>index</a>.</p>");
        out.println("\n</body> </html>");
    }

    /*
     * Takes a map "wordMap" and creates an aphabetized stack of string keys to
     * return
     *
     * @param wordMap word -> definition
     *
     * @ensures alphabetized stack of keys
     *
     * @requires wordMap is filled
     */
    public static Stack<String> alphabetizeKeys(Map<String, String> wordMap) {

        //create return variable and map copy to preserve wordMap
        Stack<String> keys = new Stack2<String>();
        Map<String, String> mapCopy = wordMap.newInstance();

        //create initial size variable
        int mapSize = wordMap.size();

        //create String array for alphabetizing
        String[] keyArray = new String[mapSize];
        //loop through wordMap to fill array
        for (int i = 0; i < mapSize; i++) {
            Pair<String, String> item = wordMap.removeAny();
            keyArray[i] = item.key();
            mapCopy.add(item.key(), item.value());
        }
        //restore wordMap
        wordMap.transferFrom(mapCopy);

        //loop through array to compare strings and reorder
        String temp;
        for (int i = 0; i < mapSize; i++) {
            for (int j = i + 1; j < mapSize; j++) {
                if (keyArray[i].compareTo(keyArray[j]) < 0) {
                    temp = keyArray[i];
                    keyArray[i] = keyArray[j];
                    keyArray[j] = temp;
                }
            }
        }

        //fill stack with properly ordered keys
        for (int i = 0; i < mapSize; i++) {
            keys.push(keyArray[i]);
        }

        return keys;
    }

    /*
     * Takes a wordMap and checks definitions for occuring terms, formatting the
     * term into html link format
     *
     * @param wordMap word -> definition
     *
     * @ensures HTML formatted terms within definitions
     *
     * @requires wordMap is filled
     */
    public static void formatForHTML(Map<String, String> wordMap) {

        //create copy to restore wordMap
        Map<String, String> copy = wordMap.newInstance();
        //loop to check if terms appear inside definition
        while (wordMap.size() > 0) {
            Pair<String, String> item = wordMap.removeAny();
            String definition = item.value();
            String[] terms = definition.split(" ");
            //check array to see if any fragment is a key
            for (int i = 0; i < terms.length; i++) {
                if (wordMap.hasKey(terms[i]) || copy.hasKey(terms[i])) {
                    //format definition variable with linked term
                    definition = definition.replaceAll(terms[i], "<a href="
                            + terms[i] + ".html>" + terms[i] + "</a>");
                }
            }
            copy.add(item.key(), definition);
        }
        //restore wordMap
        wordMap.transferFrom(copy);
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //ask for input file to generate from and output file to output to
        out.print("Enter an input file to generate items from: ");
        String inputFileName = in.nextLine();
        out.print("Enter the name of an output file: ");
        String outputFolderName = in.nextLine();
        SimpleWriter fileOut = new SimpleWriter1L(
                outputFolderName + "/index.html");

        //create new map and fill using getWordMap function
        Map<String, String> wordMap = new Map2<String, String>();
        getWordMap(inputFileName, wordMap);

        //create stack for alphabetized keys
        Stack<String> keysSorted = new Stack2<String>();
        keysSorted.transferFrom(alphabetizeKeys(wordMap));

        //begin creating html glossary index
        fileOut.println(
                "<html> <head> <title> Glossary </title> </head> <body>");
        fileOut.println("<h1> Glossary </h1>");
        fileOut.println("<hr class=\"hr3\">");
        fileOut.println("<h3> Index </h3>");
        fileOut.println("<ul>");

        //format definitions inside wordMap to be links
        //to terms inside definitions
        formatForHTML(wordMap);

        //loop through words stack and map to construct elements of glossary
        for (int i = 0; i < wordMap.size(); i++) {
            fileOut.println("<li>");
            fileOut.println(
                    processItem(wordMap, keysSorted.pop(), outputFolderName));
            fileOut.println("</li>");
        }

        //output closing file syntax
        fileOut.println("</ul>\r\n</body> </html>");
        out.println("Done!");
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
        fileOut.close();
    }

}
