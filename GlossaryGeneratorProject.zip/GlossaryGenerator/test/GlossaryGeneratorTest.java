import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;
import components.map.Map2;
import components.stack.Stack;
import components.stack.Stack2;

public class GlossaryGeneratorTest {

    @Test
    public void testGetWordMap1() {
        Map<String, String> map = new Map2();
        map.add("code", "program instructions");
        map.add("computer",
                "an electronic device for storing and processing data");
        map.add("data",
                "facts and statistics collected together for reference or analysis");
        map.add("processor", "a machine that processes something");
        map.add("program",
                "a series of coded software instructions to control the operation of a computer");
        map.add("software",
                "the programs and other operating information used by a computer");

        Map<String, String> wordMap = new Map2();

        GlossaryGenerator.getWordMap("test/test1.txt", wordMap);

        assertEquals(map, wordMap);
    }

    @Test
    public void testGetWordMap2() {
        Map<String, String> map = new Map2();
        map.add("book", "a printed or written literary work");
        map.add("definition",
                "a sequence of words that gives meaning to a term");
        map.add("glossary",
                "a list of difficult or specialized terms, with their definitions,usually near the end of a book");
        map.add("language",
                "a set of strings of characters, each of which has meaning");
        map.add("meaning",
                "something that one wishes to convey, especially by language");
        map.add("term", "a word whose definition is in a glossary");
        map.add("word",
                "a string of characters in a language, which has at least one character");

        Map<String, String> wordMap = new Map2();

        GlossaryGenerator.getWordMap("data/terms.txt", wordMap);

        assertEquals(map, wordMap);
    }

    @Test
    public void testFormatForHTML1() {
        Map<String, String> map1 = new Map2();
        map1.add("book", "a printed or written literary work");
        map1.add("definition",
                "a sequence of words that gives meaning to a term");
        map1.add("glossary",
                "a list of difficult or specialized terms, with their definitions,usually near the end of a book");
        map1.add("language",
                "a set of strings of characters, each of which has meaning");
        map1.add("meaning",
                "something that one wishes to convey, especially by language");
        map1.add("term", "a word whose definition is in a glossary");
        map1.add("word",
                "a string of characters in a language, which has at least one character");

        Map<String, String> map2 = new Map2();
        map2.add("book", "a printed or written literary work");
        map2.add("definition",
                "a sequence of words that gives <a href=meaning.html>meaning</a> to a <a href=term.html>term</a>");
        map2.add("glossary",
                "a list of difficult or specialized terms, with their definitions,usually near the end of a <a href=book.html>book</a>");
        map2.add("language",
                "a set of strings of characters, each of which has <a href=meaning.html>meaning</a>");
        map2.add("meaning",
                "something that one wishes to convey, especially by <a href=language.html>language</a>");
        map2.add("term",
                "a <a href=word.html>word</a> whose <a href=definition.html>definition</a> is in a <a href=glossary.html>glossary</a>");
        map2.add("word",
                "a string of characters in a language, which has at least one character");

        GlossaryGenerator.formatForHTML(map1);
        assertEquals(map1, map2);

    }

    @Test
    public void testAlphabetizeKeys1() {

        Map<String, String> map = new Map2();
        map.add("book", "a printed or written literary work");
        map.add("definition",
                "a sequence of words that gives meaning to a term");
        map.add("glossary",
                "a list of difficult or specialized terms, with their definitions,usually near the end of a book");
        map.add("language",
                "a set of strings of characters, each of which has meaning");
        map.add("meaning",
                "something that one wishes to convey, especially by language");
        map.add("term", "a word whose definition is in a glossary");
        map.add("word",
                "a string of characters in a language, which has at least one character");

        Stack<String> keys = new Stack2<String>();
        keys.push("word");
        keys.push("term");
        keys.push("meaning");
        keys.push("language");
        keys.push("glossary");
        keys.push("definition");
        keys.push("book");

        Stack<String> result = GlossaryGenerator.alphabetizeKeys(map);

        assertEquals(keys, result);
    }

    @Test
    public void testAlphabetizeKeys2() {

        Map<String, String> map = new Map2();
        map.add("code", "program instructions");
        map.add("computer",
                "an electronic device for storing and processing data");
        map.add("data",
                "facts and statistics collected together for reference or analysis");
        map.add("processor", "a machine that processes something");
        map.add("program",
                "a series of coded software instructions to control the operation of a computer");
        map.add("software",
                "the programs and other operating information used by a computer");

        Stack<String> keys = new Stack2<String>();
        keys.push("software");
        keys.push("program");
        keys.push("processor");
        keys.push("data");
        keys.push("computer");
        keys.push("code");

        Stack<String> result = GlossaryGenerator.alphabetizeKeys(map);

        assertEquals(keys, result);
    }

}
